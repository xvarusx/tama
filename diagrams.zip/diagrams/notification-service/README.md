# Notification Service — Correct Diagrams

This folder contains the **corrected and complete** set of diagrams for the Notification Service.

All previous design problems have been fixed:
- Notification (inbox) and Delivery (email) lifecycles are separated
- Outbox pattern is used
- Proper idempotency with ProcessedEvent
- Dead-letter queue for invalid messages
- Missing entities and actors added
- Real sequence diagram instead of boxes + text

## Diagrams

| File | Type | Description |
|------|------|-------------|
| `01-class-diagram.mmd` | Class | Domain model (entities + relationships) |
| `02-state-notification.mmd` | State | Inbox item lifecycle (UNREAD → READ → ARCHIVED) |
| `03-state-delivery.mmd` | State | Email delivery lifecycle |
| `04-sequence-event-to-delivery.mmd` | Sequence | Full flow from event to email delivery |
| `05-architecture.drawio` | Architecture | High-level system architecture |
| `06-use-case.mmd` | Use Case | Actors and use cases |
| `07-component.mmd` | Component | Internal components of the service |
| `08-activity-process-event.mmd` | Activity | Activity flow when processing an event |
| `notification-requested.example.json` | Contract | Example of the event published by producers |

## How to view

- `.mmd` files → https://mermaid.live or draw.io (Arrange → Insert → Advanced → Mermaid)
- `.drawio` file → https://app.diagrams.net

## Reconciliation with the implementation (2026-11-17)

The diagrams were compared against the running `services/notification-service` code and
the approved design spec (`docs/superpowers/specs/2026-11-16-notification-service-design.md`).
The following corrections were made so the diagrams reflect the actual model:

- **Class diagram**: `recipientId` and preference `userId` are `int` (not `Uuid`);
  `severity` is a `Severity` enum (the enum was added); `Delivery`/`DeliveryAttempt`
  hold object references (`Notification`/`Delivery`) rather than scalar id fields;
  omitted fields (`visibleInApp`, `dedupKey`, `archivedAt`, `attempts`, `recipientEmail`,
  `sendingAt`, `lastError`, `sentAt`, …) and `reclaimStale()` were added; the persisted
  `Recipient` read model was replaced by a `Recipient` value object resolved through
  `AuthServiceClient` (the design decision), with dashed "resolved via" associations.
- **Delivery state diagram**: the `RETRY_WAITING → QUEUED` and `RETRY_WAITING → FAILED`
  edges were removed — no such methods exist. The worker calls `markSending()`
  (`RETRY_WAITING → SENDING`) first; `markFailed()` (`SENDING → FAILED`) covers both
  permanent errors and retry-limit exhaustion. `reclaimStale()` (`SENDING →
  RETRY_WAITING`) was added.
- **Sequence / activity / component / architecture**: audience resolution now goes
  through `AuthServiceClient` (HTTP call to the auth-service internal user directory)
  rather than a persisted read model fed by broker user events.

The runtime pieces described here (event consumer, delivery worker, REST API) are
delivered in line with the implementation plan at
`docs/superpowers/plans/2026-11-16-notification-service.md`.
