# Reporting Service: diagrams (proposed design)

Editable sources. Nothing here is built yet; it is a proposed design.

| File | Diagram | Opens with |
|---|---|---|
| 01-class-diagram.mmd | Class diagram | Mermaid |
| 02-use-cases.drawio | Use cases | draw.io |
| 03-state-report-run.mmd | Report run status | Mermaid |
| 04-state-report-schedule.mmd | Report schedule status | Mermaid |
| 05-sequence-export-report.mmd | Export a report in the background | Mermaid |
| 06-sequence-update-facts.mmd | Update fact tables from an event | Mermaid |
| 07-architecture.drawio | Service internals and neighbours | draw.io |
| 08-system-flow.mmd | End-to-end flow | Mermaid |

## How to open

- `.drawio`: https://app.diagrams.net, File > Open From > Device.
- `.mmd`: in draw.io use Arrange > Insert > Advanced > Mermaid and paste the file, or paste it into https://mermaid.live.
