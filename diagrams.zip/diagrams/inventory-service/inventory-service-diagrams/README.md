# Inventory Service diagrams

This package contains seven editable diagrams in diagrams.net / draw.io format, modeled after the supplied invoice-service diagram set.

## Files
1. `architecture-diagram.drawio` — Symfony service, database, Redis, RabbitMQ, and service boundaries.
2. `use-cases.drawio` — operator and service integration use cases.
3. `class-diagram.drawio` — Inventory aggregate, InventoryMovement ledger, service, DTOs, and events.
4. `behavior-diagram-stock-level.drawio` — derived stock-level behavior (not a mutable invoice-like lifecycle).
5. `sequence-incoming-stock.drawio` — receiving stock from an incoming order event.
6. `sequence-outgoing-stock.drawio` — issuing stock for an outgoing sale order.
7. `system-flow.drawio` — end-to-end command/event processing and consistency boundaries.

## Open / edit
Open https://app.diagrams.net/ and choose **File → Open From → Device**, then select any `.drawio` file.

## Design assumptions to validate
- These are proposed diagrams, not a claim that every capability is implemented.
- `productId` and order references are IDs owned by other services; there are no cross-service Doctrine relations.
- Stock quantity units/precision must match the product unit and business rules.
- Negative stock is rejected by default; decide explicitly if backorders are supported.
- The exact incoming/outgoing order event names and payload contracts should be aligned with the Order Service.
- A transactional outbox and event-consumption deduplication are recommended for reliable RabbitMQ integration.
- Redis is a cache only; MySQL remains the source of truth.
- LOW_STOCK depends on a configured threshold; it is a derived condition, not a persisted workflow state.
